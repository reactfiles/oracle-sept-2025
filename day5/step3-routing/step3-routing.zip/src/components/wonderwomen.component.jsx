function WonderWomenComp() {
  return <div>
            <h2>WonderWomen Component</h2>
         </div>
}
export default WonderWomenComp
