function BatmanMovie1Comp() {
  return <div>
            <h2>Batman Movie 1 Component</h2>
            <hr />
            <h3>Batman Begins</h3>
         </div>
}
export default BatmanMovie1Comp
