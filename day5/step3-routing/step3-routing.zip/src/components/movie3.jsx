function BatmanMovie3Comp() {
  return <div>
            <h2>Batman Movie 3 Component</h2>
            <hr />
            <h3>The Dark Knight Raises</h3>
         </div>
}
export default BatmanMovie3Comp
