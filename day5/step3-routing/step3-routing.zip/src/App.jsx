import { BrowserRouter, Link, NavLink, Route, Routes } from "react-router";
import HomeComp from "./components/home.component";
import {lazy, Suspense} from "react";
/* 
import BatmanComp from "./components/batman.component";
import SupermanComp from "./components/superman.component";
import AquamanComp from "./components/aquaman.component";
import WonderWomenComp from "./components/wonderwomen.component";
import FlashComp from "./components/flash.component";
import NotFoundComp from "./components/notfound.component";
import BatmanMovie1Comp from "./components/batman_movie1.component";
import BatmanMovie2Comp from "./components/batman_movie2.component";
import BatmanMovie3Comp from "./components/batman_movie3.component"; 
*/
import "./assets/routes.css";

function App() {
  let BatmanComp = lazy(()=> import("./components/batman.component"))
  let SupermanComp = lazy(()=> import("./components/superman.component"))
  let AquamanComp = lazy(()=> import("./components/aquaman.component"))
  let WonderWomenComp = lazy(()=> import("./components/wonderwomen.component"))
  let FlashComp = lazy(()=> import("./components/flash.component"))
  let NotFoundComp = lazy(()=> import("./components/notfound.component"))
  let BatmanMovie1Comp = lazy(()=> import("./components/movie1"))
  let BatmanMovie2Comp = lazy(()=> import("./components/movie2"))
  let BatmanMovie3Comp = lazy(()=> import("./components/movie3"))
  return <div className="container">
            <h1>React Routing</h1>
            <BrowserRouter>
                {/* Basic Navigation */}
                <ul className="nav">
                  <li className="nav-item"> <NavLink className={({ isActive })=> isActive ? "nav-link box" : "nav-link"} to="/"> Home </NavLink> </li>
                  <li className="nav-item"> <NavLink className={({ isActive })=> isActive ? "nav-link box" : "nav-link"} to="batman"> Batman </NavLink> </li>
                  <li className="nav-item"> <NavLink className={({ isActive })=> isActive ? "nav-link box" : "nav-link"} to="batman/batmovie1"> Batman Movie 1</NavLink></li> 
                  <li className="nav-item"> <NavLink className={({ isActive })=> isActive ? "nav-link box" : "nav-link"} to="batman/batmovie2"> Batman Movie 2</NavLink> </li> 
                  <li className="nav-item"> <NavLink className={({ isActive })=> isActive ? "nav-link box" : "nav-link"} to="batman/batmovie3"> Batman Movie 3</NavLink> </li> 
                  <li className="nav-item"> <NavLink className={({ isActive })=> isActive ? "nav-link box" : "nav-link"} to="superman"> Superman </NavLink> </li>
                  <li className="nav-item"> <NavLink className={({ isActive })=> isActive ? "nav-link box" : "nav-link"} to="aquaman"> Aquaman </NavLink> </li>
                  <li className="nav-item"> <NavLink className={({ isActive })=> isActive ? "nav-link box" : "nav-link"} to="wonderwomen"> Wonder Women </NavLink> </li>
                  <li className="nav-item"> <NavLink className={({ isActive })=> isActive ? "nav-link box" : "nav-link"} to="flash"> Flash </NavLink> </li>
                  <li className="nav-item"> <NavLink className={({ isActive })=> isActive ? "nav-link box" : "nav-link"} to="*"> Others </NavLink> </li>
                </ul>
                <Routes>
                  <Route path="/" element={<Suspense fallback={<> loading... </>}> <HomeComp/> </Suspense>} />
                  <Route path="batman" element={<Suspense fallback={<> loading... </>}> <BatmanComp/> </Suspense>}>
                    <Route path="batmovie1" element={<Suspense fallback={<> loading... </>}> <BatmanMovie1Comp/> </Suspense>} />
                    <Route path="batmovie2" element={<Suspense fallback={<> loading... </>}> <BatmanMovie2Comp/> </Suspense>} />
                    <Route path="batmovie3" element={<Suspense fallback={<> loading... </>}> <BatmanMovie3Comp/> </Suspense>} />
                  </Route>
                  <Route path="superman" element={<Suspense fallback={<> loading... </>}> <SupermanComp/> </Suspense>} />
                  <Route path="aquaman" element={<Suspense fallback={<> loading... </>}> <AquamanComp/> </Suspense>} />
                  <Route path="wonderwomen" element={<Suspense fallback={<> loading... </>}> <WonderWomenComp/> </Suspense>} />
                  <Route path="flash" element={<Suspense fallback={<> loading... </>}> <FlashComp/> </Suspense>} />
                  <Route path="*" element={<Suspense fallback={<> loading... </>}> <NotFoundComp/> </Suspense>} />
                </Routes>
            </BrowserRouter>
         </div>
}
export default App
