let FunComp = (props) => {
    console.log("FunComp was rendered", Math.random())
    return <div className="card">
            <div className="card-body">
                <h2 className="card-title">Function Based Component</h2>
                <h3>Power is : {props.power}</h3>
            </div>
        </div>
}

export default FunComp