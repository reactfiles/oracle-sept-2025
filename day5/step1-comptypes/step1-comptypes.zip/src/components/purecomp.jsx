import {  PureComponent } from "react";

class PureClassComp extends PureComponent{
    render(){
        console.log("PureClassComp was rendered", Math.random())
        return <div className="card">
            <div className="card-body">
                <h2 className="card-title">PureClassComp Based Component</h2>
                <h3>Power is : {this.props.power}</h3>
            </div>
        </div>
    }
}

export default PureClassComp