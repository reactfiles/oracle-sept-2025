import { Component } from "react";

class ClassComp extends Component{
    render(){
        console.log("ClassComp was rendered", Math.random())
        return <div className="card">
            <div className="card-body">
                <h2 className="card-title">Class Based Component</h2>
                <h3>Power is : {this.props.power}</h3>
            </div>
        </div>
    }
}

export default ClassComp