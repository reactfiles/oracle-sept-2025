import React from 'react';

let MemoComp = (props) => {
    console.log("MemoComp was rendered", Math.random())
    return <div className="card">
            <div className="card-body">
                <h2 className="card-title">Memo function Based Component</h2>
                <h3>Power is : {props.power}</h3>
            </div>
        </div>
}

// 
export default React.memo(MemoComp)