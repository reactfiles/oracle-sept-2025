import { useState } from "react"
import ClassComp from "./components/classcomp"
import FunComp from "./components/funcomp"
import PureClassComp from "./components/purecomp"
import Memocomp from "./components/memocomp"

function App() {
  let [power, setPower] = useState(0);
  let [classcomp_power, setClassPower] = useState(0);
  let [funcomp_power, setFunPower] = useState(0);
  let [purecomp_power, setPurePower] = useState(0);
  let [memocomp_power, setMemoPower] = useState(0);
  return <div className="container">
          <h1>Component Types</h1>
          <h2>Power is : { power }</h2>
          <button onClick={()=> setPower(power+1)}>Increase Power</button>
          <button onClick={()=> setPower(power-1)}>Decrease Power</button>
          <hr />
          <button onClick={()=> setClassPower(Math.round(Math.random() * 100))}>Set Class Power</button>
          <button onClick={()=> setFunPower(Math.round(Math.random() * 100))}>Set Fun Power</button>
          <button onClick={()=> setPurePower(Math.round(Math.random() * 100))}>Set Pure Power</button>
          <button onClick={()=> setMemoPower(Math.round(Math.random() * 100))}>Set Memo Power</button>
          <ClassComp power={classcomp_power}/>
          <FunComp power={funcomp_power}/>
          <hr />
          <PureClassComp power={purecomp_power}/>
          <Memocomp power={memocomp_power}/>
        </div>
}

export default App
