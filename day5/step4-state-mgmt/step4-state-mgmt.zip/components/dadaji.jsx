import { useState } from "react";
import PapajiComp from "./papaji";
import { FamilyContext } from "../contexts/family.context";
import Cousinji from "./cousinji";

let DadajiComp = () => {
    let [ state , setState ] = useState({  message : "default", ipval : "" })
        return <div style={ { border : "2px solid red", padding : "10px", margin : "10px" } }>
                    <h1>Grand Parent Component</h1>
                    <input value={state.ipval} onChange={ (evt) => setState({...state, ipval : evt.target.value })} type="text" />
                    <button onClick={() => setState({...state, message : state.ipval })}>Send Message</button>
                    <FamilyContext.Provider value={state.message} >
                        <div>
                            <PapajiComp/>
                        </div>
                        <Cousinji/>
                    </FamilyContext.Provider>
                </div>
}

export default DadajiComp