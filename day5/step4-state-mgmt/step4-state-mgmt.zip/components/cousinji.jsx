import { Component } from "react";
import { FamilyContext } from "../contexts/family.context";

class Cousinji extends Component{
    render(){
        return <div style={ { border : "2px solid red", padding : "10px", margin : "10px" } }>
                    <h1>Cousin Component</h1>
                    <FamilyContext.Consumer>{ (val) => <h3>{ val }</h3>  }</FamilyContext.Consumer>
                </div>
    }
}

export default Cousinji