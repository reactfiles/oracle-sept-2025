import { useContext } from "react";
import {  FamilyContext } from "../contexts/family.context";

let BetajiComp = () => {
    let val = useContext(FamilyContext);
    return <div style={ { border : "2px solid red", padding : "10px", margin : "10px" } }>
                <h1>Child Component</h1>
                <h3>{ val }</h3>
                <h3>{ val }</h3>
                <h3>{ val }</h3>
                <h3>{ val }</h3>
                <h3>{ val }</h3>
            </div>
}

export default BetajiComp