import BetajiComp from "./betaji";

let PapajiComp = () => {
    return <div style={ { border : "2px solid red", padding : "10px", margin : "10px" } }>
                <h1>Parent Component</h1>
                <BetajiComp/>
            </div>

}

export default PapajiComp