function App() {
  return <div>
    <h1>Welcome to your life</h1>
  </div>
}

export default App
