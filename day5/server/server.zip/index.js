// import modules 
let express = require("express");
let cors = require("cors");
let mongoose = require("mongoose");
let config = require("./config");
// configure web server
let app = express();
    app.use(express.json());
    app.use(cors());
// configure DB
let dbcon = "mongodb+srv://$uname:{{upass}}@cluster0.{{dbstring}}.mongodb.net/{dbname}?retryWrites=true&w=majority&appName=Cluster0";
let url = dbcon.replace("$uname",config.dbuser).replace("{{upass}}",config.dbpass).replace("{dbname}", config.dbname).replace("{{dbstring}}",config.dbstring);

mongoose.connect(url)
.then(res => console.log("DB Connected"))
.catch(err => console.log("Error", err));

// models
let Schema = mongoose.Schema;
let ObjectId = Schema.ObjectId;
let User = mongoose.model("User", new Schema({
    id : ObjectId,
    title : String,
    firstname : String,
    lastname : String,
    city : String,
    power : String
}));

// routes
// read
app.get("/data",(req, res)=>{
    User.find().then(dbres => res.json(dbres))
});
// write
app.post("/data",(req, res)=>{
    let user = new User(req.body);
    user.save()
    .then(dbres => {
        res.json({"message":"user was added"})
        console.log("user was added");
    })
    .catch(err => console.log("Error", err));
});
// delete
app.delete("/delete/:id", (req, res) => {
    User.findByIdAndDelete(req.params.id)
    .then(dbres => res.json({"message":"User was deleted"}))
    .catch(err => console.log("Error", err));
});
// read to update
app.get("/edit/:id", (req, res) => {
    User.findById(req.params.id)
    .then(dbres => res.json(dbres))
    .catch(err => console.log("Error", err));
});
// update
app.put("/edit/:id", (req, res) =>{
    // Hero.findByIdUpdate({ _id : req.params.id })
    User.findById(req.params.id)
    .then(dbres => {
        dbres.title = req.body.title;
        dbres.firstname = req.body.firstname;
        dbres.lastname = req.body.lastname;
        dbres.city = req.body.city;
        dbres.power = req.body.power;
        dbres.save()
        .then(dbSaveRes => res.json({"message":"user info is saved"}))
        .catch(err => console.log("Error in saving", err));
    })
    .catch(err => console.log("Error in updating", err));
})

app.listen(config.port,config.host,(error)=>{
    if(error){ console.log("Error ", error)}
    else{ console.log("server is now live on localhost:5050")}
})

