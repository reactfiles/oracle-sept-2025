let config = {
    dbuser : "vboxin_db_user",
    dbpass : "M8ik4hMk0aSS8AxH",
    dbstring : "s4hxy3a",
    dbname : "oracle_db",
    port : 5050,
    host : "localhost"
};

module.exports = config;