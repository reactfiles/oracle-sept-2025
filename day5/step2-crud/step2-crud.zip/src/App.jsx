import { useEffect, useState } from "react";
import axios from "axios";

function App() {
  let refresh = async function (){
    return await axios.get("http://localhost:5050/data").then(res => setUsers(res.data))
      .catch(err => console.log("Error ", err))
  }
  // list of users
  let [users, setUsers] = useState([]);
  
  // show/hide add and edit
  let [show, setShow] = useState(true);
  // store user
  let [user, setUser] = useState({
        title : "",
        firstname : "",
        lastname : "",
        city : "",
        power : ""
  });
  let [edit_user, setEditUser] = useState({
        _id : "",
        title : "",
        firstname : "",
        lastname : "",
        city : "",
        power : ""
  });
  useEffect(()=>{
      refresh()
  },[]);

  let userHandler = (evt) =>{
    setUser({...user, [evt.target.id] : evt.target.value})
  }
  let addUserHandler = () => {
    axios.post("http://localhost:5050/data",user)
    .then(res => { 
     console.log(res.data.message)
     refresh()
      // .then(dbres => setUsers(dbres.data))
      // .catch(err => console.log("Error ", err))
    })
    .catch(err => console.log("Error", err))
  };
  let editUserHandler = (uid) => {
   axios.get("http://localhost:5050/edit/"+uid)
   .then(dbres=>{
    setEditUser(dbres.data);
    setShow(!show);
   })
   .catch(err => console.log("Error", err))
  }
  let editedUserUpdateHandler = () => {
    axios.put("http://localhost:5050/edit/"+edit_user._id,edit_user)
    .then(dbres => {
      console.log(dbres.data.message);
      setShow(!show);
      refresh();
    })
    .catch(err => console.log("Error", err))
  }
  let deleteUserHandler = (uid) => {
      axios.delete("http://localhost:5050/delete/"+uid)
      .then(res => { 
      console.log(res.data.message)
      refresh()
      // .then(dbres => setUsers(dbres.data))
      // .catch(err => console.log("Error ", err))
    })
    .catch(err => console.log("Error", err))
  }
  let updateInfoHandler = (evt) => {
      setEditUser({...edit_user, [evt.target.id] : evt.target.value})
  }
  return <div className="container">
            <h1>React CRUD Application</h1>
            
            { show &&             <div className="card">
              <div className="card-body">
                <h3 className="card-title">Add New User</h3>
                  <div className="mb-3">
                    <label htmlFor="title" className="form-label">User Title</label>
                    <input onChange={userHandler} className="form-control" id="title"/>
                  </div>
                  <div className="mb-3">
                    <label htmlFor="firstname" className="form-label">First Name</label>
                    <input onChange={userHandler} className="form-control" id="firstname"/>
                  </div>
                  <div className="mb-3">
                    <label htmlFor="lastname" className="form-label">Last Name</label>
                    <input onChange={userHandler} className="form-control" id="lastname"/>
                  </div>
                  <div className="mb-3">
                    <label htmlFor="city" className="form-label">City</label>
                    <input onChange={userHandler} className="form-control" id="city"/>
                  </div>
                  <div className="mb-3">
                    <label htmlFor="power" className="form-label">Power</label>
                    <input onChange={userHandler} type="range" min={0} max={10} step={1} className="form-control" id="power"/>
                  </div>
                  <button onClick={addUserHandler} className="btn btn-primary">Add User</button>
              </div>
            </div> }

            { !show &&             <div className="card">
              <div className="card-body">
                <h3 className="card-title">Edit User Info</h3>
                  <div className="mb-3">
                    <label htmlFor="title" className="form-label">Edit Title</label>
                    <input value={edit_user.title} onChange={updateInfoHandler} className="form-control" id="title"/>
                  </div>
                  <div className="mb-3">
                    <label htmlFor="firstname" className="form-label">Edit First Name</label>
                    <input value={edit_user.firstname} onChange={updateInfoHandler} className="form-control" id="firstname"/>
                  </div>
                  <div className="mb-3">
                    <label htmlFor="lastname" className="form-label">Edit Last Name</label>
                    <input value={edit_user.lastname} onChange={updateInfoHandler} className="form-control" id="lastname"/>
                  </div>
                  <div className="mb-3">
                    <label htmlFor="city" className="form-label">Edit City</label>
                    <input value={edit_user.city} onChange={updateInfoHandler} className="form-control" id="city"/>
                  </div>
                  <div className="mb-3">
                    <label htmlFor="power" className="form-label">Edit Power</label>
                    <input value={edit_user.power} onChange={updateInfoHandler} type="range" min={0} max={10} step={1} className="form-control" id="power"/>
                  </div>
                  <button onClick={editedUserUpdateHandler} className="btn btn-primary">Update User Info</button>
                  <br />
              </div>
            </div> }

            <div className="card">
              <div className="card-body">
                <h3 className="card-title">Users List</h3>
                <table className="table table-striped table-hover table-responsive">
                <thead className="table-dark">
                  <tr>
                    <th>Sl #</th>
                    <th>Title</th>
                    <th>First Name</th>
                    <th>Last Name</th>
                    <th>City</th>
                    <th>Power</th>
                    <th>Edit</th>
                    <th>Delete</th>
                  </tr>
                </thead>
                <tbody>
                  { users.map((val, idx) => <tr key={val._id}>
                    <td>{idx+1}</td>
                    <td>{val.title}</td>
                    <td>{val.firstname}</td>
                    <td>{val.lastname}</td>
                    <td>{val.city}</td>
                    <td>{val.power}</td>
                    <td><button onClick={() => editUserHandler(val._id) } className="btn btn-warning">Edit</button></td>
                    <td><button onClick={() => deleteUserHandler(val._id) } className="btn btn-danger">Delete</button></td>
                  </tr>)}
                </tbody>
              </table>
              </div>

            </div>
         </div>
}

export default App
