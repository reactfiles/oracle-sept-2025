import { ADD_HERO, REMOVE_HERO, SET_HERO } from "../types/hero.types"

// HERO ACTION 
export const addHero = () => {
    return {
        type : ADD_HERO
    }
}
export const removeHero = () => {
    return {
        type : REMOVE_HERO
    }
}
export const setHero = (args) => {
    return {
        type : SET_HERO,
        payload : args
    }
}