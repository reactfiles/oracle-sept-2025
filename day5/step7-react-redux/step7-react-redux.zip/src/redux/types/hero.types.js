// HERO TYPE
export const ADD_HERO = "ADD_HERO";
export const REMOVE_HERO = "REMOVE_HERO";
export const SET_HERO = "SET_HERO";
