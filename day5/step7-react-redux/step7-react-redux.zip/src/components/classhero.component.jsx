import { Component } from "react";
// import { addHero } from "../redux/actions/hero.actions";
import { addHero, removeHero, setHero } from "../redux/index";
import { connect } from "react-redux";

class ClassHeroComponent extends Component{
    
    render(){
        return <div>
                    <h1>Class Component with React Redux </h1>
                    <h2>Avengers : { this.props.numberOfHeroes }</h2>
                    <button onClick={ this.props.addHero }>Add Avenger</button>
                    <button onClick={ this.props.removeHero }>Remove Avenger</button>
                    <input value={ this.props.numberOfHeroes } type="range" onChange={ (evt)=>this.props.setHero(Number(evt.target.value)) } />
                </div>
    }
}
const mapStateToProps = (state) => {
    return {
        numberOfHeroes : state.numberOfHeroes
    }
}
const mapDispatchToProps = (dispatch) => {
    return {
        addHero : () => dispatch(addHero()),
        removeHero : () => dispatch(removeHero()),
        setHero : (val) => dispatch(setHero(val))
    }
}
// mapStateToProps?, mapDispatchToProps
export default connect(mapStateToProps, mapDispatchToProps)(ClassHeroComponent);