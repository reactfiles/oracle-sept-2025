// import { addHero } from "../redux/actions/hero.actions";
import { addHero, removeHero, setHero } from "../redux/index";
import { useDispatch, useSelector } from "react-redux";

let FunHeroComponent = () => {
    let numberOfHeroes = useSelector( state => state.numberOfHeroes );
    let dispatch = useDispatch();

    return <div>
                <h1>Function Component with React Redux </h1>
                <h2>Avengers : { numberOfHeroes }</h2>
                <button onClick={ () => dispatch( addHero() ) }>Add Avenger</button>
                <button onClick={ () => dispatch(removeHero() ) }>Remove Avenger</button>
                <input 
                value={numberOfHeroes} 
                type="range" 
                onChange={ (evt)=>dispatch( setHero(Number(evt.target.value))) } />
            </div>
}

export default FunHeroComponent;