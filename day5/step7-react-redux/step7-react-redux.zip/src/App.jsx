import ClassHeroComponent from "./components/classhero.component";
import { Provider } from "react-redux";
import store from "./redux/store";
import FunHeroComponent from "./components/funhero.component";

let App = () => {
    return <div>
        <Provider store={ store }>
            <ClassHeroComponent/>
            <FunHeroComponent/>
        </Provider>
    </div>
}

export default App;