import UserForm from "./components/userform"

function App() {
  return <div className="container">
          <h1>React Form Validation </h1>
          <UserForm/>
         </div>
}

export default App
