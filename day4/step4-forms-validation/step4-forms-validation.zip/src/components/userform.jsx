import { useState } from "react";

let UserForm = () => {
    let [userdata, setUserData] = useState({
        username : '',
        useremail : '',
        userage : ''
    });
    let [datavalidation, setDataValidation] = useState({
        usernameValid : false,
        useremailValid : false,
        userageValid : false,
        userNameMessage : "a",
        usereMailMessage : "a",
        userAgeMessage : "a"
    });
    /* 
    let userNameHandler = (evt) => {
        setUserData({...userdata, username : evt.target.value })
    };
    let userEmailHandler = (evt) => {
        setUserData({...userdata, useremail : evt.target.value })
    };
    let userAgeHandler = (evt) => {
        setUserData({...userdata, userage : evt.target.value })
    }; 
    */
    let userFormHandler = (evt) => {
        setUserData({...userdata, [evt.target.id] : evt.target.value });
    }; 
    let validateUserInput = () => {
        // console.log(userdata.username.length);
        if(userdata.username.length < 1 && userdata.useremail.length < 1 && userdata.userage == 0){
            
            setDataValidation({...datavalidation, 
                usernameValid : true, 
                userNameMessage : "you must enter your name",
                useremailValid : true, 
                usereMailMessage : "you must enter your eMail",
                userageValid : true, 
                userAgeMessage : "you must enter your age",
            })
        }
        else if(userdata.userage != 0){
            if(userdata.userage < 18){
                setDataValidation({...datavalidation, userageValid : true, userAgeMessage : "You are too young to join us"})
            }
            else if(userdata.userage > 90){
                setDataValidation({...datavalidation, userageValid : true, userAgeMessage : "You are too old to join us"})
            }
            else{
                setDataValidation({...datavalidation, userageValid : false, userAgeMessage : ""})
            } 
        }
        else{
                setDataValidation({...datavalidation, 
                    usernameValid : false, 
                    userNameMessage : "",
                    useremailValid : false, 
                    usereMailMessage : "",
                    userageValid : false, 
                    userAgeMessage : "",
            })
        }
        /* if(userdata.useremail.length < 1){
            setDataValidation({...datavalidation, useremailValid : true, usereMailMessage : "you must enter your eMail"})
        }  */
        /* if(userdata.userage == 0 ){
            setDataValidation({...datavalidation, userageValid : true, userAgeMessage : "you must enter your age"})
        }
        else if(userdata.userage < 18){
            setDataValidation({...datavalidation, userageValid : true, userAgeMessage : "You are too young to join us"})
        }
        else if(userdata.userage > 90){
            setDataValidation({...datavalidation, userageValid : true, userAgeMessage : "You are too old to join us"})
        }
        else{
            setDataValidation({...datavalidation, userageValid : false, userAgeMessage : ""})
        } */
    }
    return <div>
            <h2>User Registeration Form</h2>
            <div className="mb-3">
              <label htmlFor="username" className="form-label">User Name</label>
              <input value={userdata.username} onChange={userFormHandler} className="form-control" id="username"/>
              { datavalidation.usernameValid && <div className="form-text text-danger">{datavalidation.userNameMessage}</div>  }
            </div>
            <div className="mb-3">
              <label htmlFor="useremail" className="form-label">User eMail</label>
              <input value={userdata.useremail} onChange={userFormHandler} className="form-control" id="useremail"/>
              { datavalidation.useremailValid && <div className="form-text text-danger">{datavalidation.usereMailMessage}</div>  }
            </div>
            <div className="mb-3">
              <label htmlFor="userage" className="form-label">User age</label>
              <input type="number" value={userdata.userage} onChange={userFormHandler} className="form-control" id="userage"/>
              { datavalidation.userageValid && <div className="form-text text-danger">{datavalidation.userAgeMessage} </div> }
            </div>
            <hr />
            <button onClick={() => setDataValidation({...datavalidation, 
            usernameValid : !datavalidation.usernameValid,
            useremailValid : !datavalidation.useremailValid,
            userageValid : !datavalidation.userageValid,})}>Show / Hide</button>
            <button onClick={validateUserInput} className="btn btn-primary">Register</button>
            <hr />
            { JSON.stringify(userdata) }
          </div>
};

export default UserForm