import { Component } from "react";
import ChildComp from "./child";
import FunChildComp from "./funchild";
import ForHook from "./forhook";

class ParentComp extends Component{
    state = {
        power : 0,
        version : 0
    }
    constructor(){
        super();
        // console.log("parent's constructor was called")
    }
    componentDidMount(){
        // console.log("parent's componentDidMount was called")
    }
    render(){
        // console.log("parent's render was called")
        return <div style={ { border : "2px solid red", padding : "10px", margin : "10px"} }>
                    <h2>Parent Component : power {this.state.power}</h2>
                    <input step={5} type="range" onChange={(evt)=> this.setState({power : Number(evt.target.value)})} />
                    { this.state.power < 50 && <ChildComp power={this.state.power}/>  }
                    <FunChildComp power={this.state.power}/>
                    <hr />
                    <button onClick={() => this.setState({version : Math.round(Math.random() * 1000)})}>Change Version</button>
                    { this.state.power < 80 && <ForHook version={this.state.version} power={this.state.power}/> }
                </div>
    }
}

export default ParentComp