import { useEffect } from "react";

let ForHook = (props) => {
    // once when the component is mounted
    useEffect(()=>{
        console.log("ForHook Component is mounted", Math.random())
    },[])
    // everytime the component is updated
    useEffect(()=>{
        console.log("ForHook Component is updated", Math.random())
    })
    // everytime the component' power property is updated
    useEffect(()=>{
        console.log("ForHook Component is updated", Math.random())
    },[props.power])
    // when the component is unmounted
    useEffect(()=>{
        return () => {
            console.log("ForHook Component is unmounted")
        }
    },[])
    return <div className="card">
                <h2>For Hook Component</h2>
                <h3>Power : { props.power }</h3>
                <h3>Version is : { props.version }</h3>
            </div>
};

export default ForHook