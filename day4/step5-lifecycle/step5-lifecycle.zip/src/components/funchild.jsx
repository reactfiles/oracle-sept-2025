import { useState } from "react";
import { Component } from "react";
import axios from "axios";
import { useEffect } from "react";

let  FunChildComp  = (props) => {
    let [users, setUsers] = useState([])
     useEffect(()=>{
        // console.log("function component was mounted")
         axios
        .get("https://jsonplaceholder.typicode.com/users")
        .then(res => {
            setUsers(res.data)
        })
        .catch(err => console.log("Error", err))
     })
     return <div style={ { border : "2px solid blue", padding : "10px", margin : "10px"} }>
                    <h2>Function Child Component</h2>
                    <h3>Power is : { props.power }</h3>
                    
                    <hr />  
                    <ol>
                        { users.map(user => <li key={user.id}>{user.name}</li>)}
                    </ol>
                </div>
}

export default FunChildComp
