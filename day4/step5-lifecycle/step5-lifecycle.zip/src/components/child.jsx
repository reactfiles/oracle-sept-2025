import { Component } from "react";
import axios from "axios";

class ChildComp extends Component{
    state = {
        users : []
    }
    constructor(){
        super();
        //console.log("child's constructor was called")
    }
    componentDidMount(){
        // console.log("child's componentDidMount was called");
        axios
        .get("https://jsonplaceholder.typicode.com/users")
        .then(res => {
            this.setState({
                users : res.data
            })
        })
        .catch(err => console.log("Error", err))
    }
    componentDidUpdate(){
        // console.log("child's componentDidUpdate was called");
    }
    componentWillUnmount(){
        // console.log("child's componentWillUnmount was called");
    }
    render(){
        // console.log("child's render was called")
        return <div style={ { border : "2px solid blue", padding : "10px", margin : "10px"} }>
                    <h2>Child Component</h2>
                    <h3>Power is : { this.props.power }</h3>
                    <hr />  
                    <ol>
                        { this.state.users.map(user => <li key={user.id}>{user.name}</li>)}
                    </ol>
                </div>
    }
}

export default ChildComp

/* 
npm i axios
*/