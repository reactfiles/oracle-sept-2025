import ParentComp from "./components/parent"

function App() {
  return <div className="container">
          <h1>Welcome to your life</h1>
          <hr />
          <ParentComp/>
        </div>
}

export default App
