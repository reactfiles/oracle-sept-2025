import ViewComp from "./components/view"

function App() {
  return <div className="container">
          <h1>React Prop Types</h1>
          <hr />
          <ViewComp title="First Box" version={1001} power={5}/>
          <ViewComp version={1002} power={6}/>
          <ViewComp title="Third Box" power={7}/>
          <ViewComp title="Third Box"/>
          <ViewComp />
        </div>
}

export default App