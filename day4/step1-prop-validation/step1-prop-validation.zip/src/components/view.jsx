import { Component } from "react";
import PropTypes from "prop-types";

class ViewComp extends Component{
    /* 
    static defaultProps = {
        title : "Default",
        version : 1,
        power : 0
    } 
    */
   static propTypes = {
    title : PropTypes.string.isRequired,
    version : PropTypes.number.isRequired,
    power : PropTypes.number.isRequired,
   }
    render(){
        return <div className="card">
                <div className="card-body">
                    <h2 className="card-title">Title : { this.props.title } Version : { this.props.version }</h2>
                    <div className="card-text">
                        <h3>Version : { this.props.version }</h3>
                        <h3>Power : { this.props.power }</h3>
                    </div>
                </div>
                </div>
    }
}
/* 
ViewComp.defaultProps = {
    title : "Default",
    version : 1,
    power : 0
} 
*/
export default ViewComp