// import React from "react";

import { useRef } from "react";

function ChildComp(props) {
  let messageInput = useRef();
  return <div  style={ {backgroundColor : "lightblue"} }  className="card">
            <div className="card-body">
                <h1 className="card-title">Child Component</h1>
                <div>Message : {props.message || 'waiting for message'}</div>
                <hr />
                <div className="mb-3">
                    <label className="form-label">Message</label>
                    <input ref={ messageInput } className="form-control" />
                    <br />
                    <button onClick={()=> props.msgHandle(messageInput.current.value)}  className="btn btn-primary">Send Message</button>
                </div>
            </div>
        </div>
}

export default ChildComp
