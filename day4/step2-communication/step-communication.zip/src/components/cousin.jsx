function CousinComp(props) {
  return <div style={ {backgroundColor : "lightyellow"} } className="card">
            <div className="card-body">
                <h1 className="card-title">Cousin Component</h1>
                 <div>Message : {props.message || 'waiting for message'}</div>
            </div>
        </div>
}

export default CousinComp
