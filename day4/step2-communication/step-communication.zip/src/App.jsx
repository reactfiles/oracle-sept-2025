import React,{ useState } from "react"
import ChildComp from "./components/child"
import CousinComp from "./components/cousin"

function App() {
  let [message, setMessage] = useState("default message");
  let messageInput = React.createRef();
  let messageHandler = (nmessage) => {
    setMessage(nmessage)
  }
  return <div className="container">
          <h1>Component Communication in React</h1>
          <h2>{ message }</h2>
          <div className="mb-3">
            <label className="form-label">Message</label>
            <input ref={ messageInput } className="form-control" />
            <br />
            <button onClick={() => messageHandler(messageInput.current.value) } className="btn btn-primary">Send Message</button>
          </div>
          <hr />
          <ChildComp msgHandle={messageHandler} message={message}/>
          <hr />
          <CousinComp message={message}/>
        </div>
}

export default App
