import { useState } from "react"

function App() {
  let [agree, setAgree] = useState(false)
  if(agree){
    return <div className="container">
              <h1>React Conditional Rendering Agree Template</h1>
              <br />
              <label htmlFor=""> Show Terms and Conditions  &nbsp;
                <input className="form-check-input" checked={agree} type="checkbox" onChange={(evt) => setAgree(evt.target.checked) } />
              </label>
              <br />
              <hr />
              <fieldset>
                <legend>Terms & Conditions</legend>
                <hr />
                <div>
                  Lorem ipsum dolor, sit amet consectetur adipisicing elit. Vitae nemo ipsam beatae maiores vel magnam ratione nam ipsa dolores, debitis itaque doloremque dicta maxime delectus quibusdam eaque, perspiciatis veritatis, voluptatem sunt! Error nisi, quos ea possimus illo iure vero optio voluptatum eligendi similique quo nesciunt nihil placeat, adipisci nostrum officiis totam, ad odit aspernatur ab nobis fuga cumque facilis! Incidunt quaerat distinctio, perferendis ipsa nostrum esse voluptatibus repellat libero quisquam ut deserunt doloribus ea. Asperiores dolores quidem ipsum, illum fugit enim sed explicabo voluptatum ea tenetur, odit harum magnam neque officiis? Nam natus unde aliquid mollitia iure minus ea obcaecati, sint atque, voluptatem eum temporibus in inventore? Assumenda est eius repellendus architecto sapiente. Dicta, voluptates? Suscipit error vel doloremque, soluta sit repellat, molestiae voluptatibus iste modi minima architecto! In consectetur adipisci alias dolorum odit beatae eaque eligendi velit laboriosam, neque accusantium architecto aspernatur illo facilis facere labore suscipit cum provident voluptatum dolorem voluptas dignissimos quisquam aut. Fugiat quos iure dignissimos saepe laudantium pariatur suscipit consequuntur dolores quibusdam ad, illum repudiandae consequatur deserunt commodi sed voluptate adipisci iste nam neque! Omnis error molestiae facilis est porro numquam harum consequuntur quo incidunt ad tempora quam placeat, repellat eligendi velit. Sed, ex architecto.
                </div>
              </fieldset>
            </div>
      }else{
    return <div className="container">
              <h1>React Conditional Rendering Disagree Template</h1>
              <br />
              <label htmlFor=""> Show Terms and Conditions  &nbsp;
                <input className="form-check-input" checked={agree} type="checkbox" onChange={(evt) => setAgree(evt.target.checked) } />
              </label>
            </div>
      }
}

export default App
/* 
  return <div className="container">
          <h1>React Conditional Rendering</h1>
          <br />
          <label htmlFor=""> Show Terms and Conditions  &nbsp;
            <input className="form-check-input" checked={agree} type="checkbox" onChange={(evt) => setAgree(evt.target.checked) } />
          </label>
          <br />
          <hr />
          { agree && <fieldset>
            <legend>Terms & Conditions</legend>
            <hr />
            <div>
              Lorem ipsum dolor, sit amet consectetur adipisicing elit. Vitae nemo ipsam beatae maiores vel magnam ratione nam ipsa dolores, debitis itaque doloremque dicta maxime delectus quibusdam eaque, perspiciatis veritatis, voluptatem sunt! Error nisi, quos ea possimus illo iure vero optio voluptatum eligendi similique quo nesciunt nihil placeat, adipisci nostrum officiis totam, ad odit aspernatur ab nobis fuga cumque facilis! Incidunt quaerat distinctio, perferendis ipsa nostrum esse voluptatibus repellat libero quisquam ut deserunt doloribus ea. Asperiores dolores quidem ipsum, illum fugit enim sed explicabo voluptatum ea tenetur, odit harum magnam neque officiis? Nam natus unde aliquid mollitia iure minus ea obcaecati, sint atque, voluptatem eum temporibus in inventore? Assumenda est eius repellendus architecto sapiente. Dicta, voluptates? Suscipit error vel doloremque, soluta sit repellat, molestiae voluptatibus iste modi minima architecto! In consectetur adipisci alias dolorum odit beatae eaque eligendi velit laboriosam, neque accusantium architecto aspernatur illo facilis facere labore suscipit cum provident voluptatum dolorem voluptas dignissimos quisquam aut. Fugiat quos iure dignissimos saepe laudantium pariatur suscipit consequuntur dolores quibusdam ad, illum repudiandae consequatur deserunt commodi sed voluptate adipisci iste nam neque! Omnis error molestiae facilis est porro numquam harum consequuntur quo incidunt ad tempora quam placeat, repellat eligendi velit. Sed, ex architecto.
            </div>
          </fieldset> }
        </div>
*/