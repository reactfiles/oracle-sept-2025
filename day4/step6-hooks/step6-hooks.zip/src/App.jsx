/* import { useState } from "react"

function App() {
  let [userinfo, setUserInfo] = useState({ 
                                            firstname : "default first name",
                                            lastname : "default last name",
                                            city : "default last name",
                                          }); 
  return <div className="container">
          <h1>Welcome to your life</h1>
          <h3>First Name : { userinfo.firstname }</h3>
          <h3>Last Name : { userinfo.lastname }</h3>
          <h3>City : { userinfo.city }</h3>
          <hr />

          <input type="text" value={userinfo.firstname} 
          onChange={(evt) => setUserInfo({...userinfo, firstname : evt.target.value})} />

          <input type="text" value={userinfo.lastname} 
          onChange={(evt) => setUserInfo({...userinfo, lastname : evt.target.value})} />

          <input type="text" value={userinfo.city} 
          onChange={(evt) => setUserInfo({...userinfo, city : evt.target.value})} />
        </div>
}

export default App
 */

import { useReducer } from "react"

function App() {
 //  let [state, dispatch] = useReducer(reducerfun, defaultState); 
 
 let reducerFun = (state, action) => {
  switch(action.type) {
    case "UPDATEFIRSTNAME" : return {...state, firstname : action.payload }
    case "UPDATELASTNAME" : return {...state, lastname : action.payload }
    case "UPDATECITY" : return {...state, city : action.payload }
    default : return state
  }
 };

  let [userState, dispatch ] = useReducer(reducerFun, {
    firstname : "default first name",
    lastname : "default last name",
    city : "default city",
  })
  
  return <div className="container">
          <h1>Welcome to your life</h1>
          <h3>First Name : { userState.firstname }</h3>
          <h3>Last Name : { userState.lastname }</h3>
          <h3>City Name : { userState.city }</h3>
          <hr />

         <input type="text" 
          onChange={(evt) => dispatch({type : "UPDATEFIRSTNAME", payload : evt.target.value })} />

         <input type="text" 
          onChange={(evt) => dispatch({type : "UPDATELASTNAME", payload : evt.target.value })} />

         <input type="text" 
          onChange={(evt) => dispatch({type : "UPDATECITY", payload : evt.target.value })} />


        </div>
}

export default App
