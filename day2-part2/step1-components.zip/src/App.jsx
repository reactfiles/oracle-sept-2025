import Article from "./components/article";
import Footer from "./components/footer";
import Header from "./components/header";

let App = () => {
  return (
    <div>
     <Header/>
      <main>
        <section>
         <Article power={5} lable="click me" title="First Article">
          <ul>
            <li>List item 1</li>
            <li>List item 2</li>
            <li>List item 3</li>
            <li>List item 4</li>
            <li>List item 5</li>
          </ul>
          <hr />
          <select name="" id="">
            <option value="">Select the City</option>
            <option value="">bangalore</option>
            <option value="">kolkata</option>
            <option value="">patna</option>
            <option value="">pune</option>
            <option value="">mumbai</option>
          </select>
         </Article>
         <Article power={6} lable="punch me" title="Second Article">
            Lorem ipsum, dolor sit amet consectetur adipisicing elit. Perspiciatis debitis est eveniet molestias sapiente vel similique, pariatur non illo tempore nemo ducimus et nisi amet.
         </Article>
         <Article power={7} lable="hit the button" title="Third Article">
            Lorem ipsum dolor sit, amet consectetur adipisicing elit. Culpa dolorem repellendus aliquid amet voluptatum quia maxime voluptate. Dolorum dolores error voluptates voluptatem quos neque. Eligendi facilis dolorum perspiciatis consequuntur dolorem neque mollitia, quibusdam ab quas excepturi rerum sit reiciendis non dignissimos reprehenderit quaerat? Velit ducimus cupiditate, eos atque amet, impedit veniam assumenda perferendis harum at error odit! Quibusdam recusandae harum veniam tenetur magnam quo neque rem dolor vitae? Iusto, mollitia voluptates tempore dolore commodi aliquam. Eaque, delectus aliquid! Est mollitia expedita minima consequatur, excepturi soluta, repellat optio quos modi pariatur, quasi beatae aut nesciunt fuga tempore officia provident perferendis laboriosam.
         </Article>
        </section>
      </main>
      <Footer/>
    </div>
  );
};

export default App;
