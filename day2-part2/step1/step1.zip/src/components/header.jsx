let Header = () =>  <header>
                        <h2>Header Comes here</h2>
                    </header>;

export default Header;