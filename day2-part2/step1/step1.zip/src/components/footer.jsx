let Footer = () =>  <>
                        <footer>Copyrights reserved by Oracle India 2025</footer>
                        <footer>Copyrights reserved by Oracle India 2025</footer>
                    </>;

export default Footer;
