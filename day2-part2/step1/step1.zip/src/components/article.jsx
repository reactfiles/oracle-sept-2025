let Article = (props) => (
  <div>
    <h2> { props.title } </h2>
    <article>
      { props.children }
      <br />
      <h3>Power is { props.power }</h3>
      <hr />
      <button>{ props.lable }</button>
    </article>
  </div>
);

export default Article;
