let Hero = (props) => {
  return <>
         <h2>{props.title}</h2>
        {/*  
        <ol>
            <li>{props.list[0]}</li>
            <li>{props.list[1]}</li>
            <li>{props.list[2]}</li>
            <li>{props.list[3]}</li>
            <li>{props.list[4]}</li>
         </ol> 
         */}
         {/* <button onClick={()=>{
          // console.log(props.title)
          props.title = "Changed"
         }}>Change Title</button> */}
          <ol>
            { props.list.map((val,idx) => <li key={idx}>{val}</li>) }
         </ol>
        </>
};

export default Hero;