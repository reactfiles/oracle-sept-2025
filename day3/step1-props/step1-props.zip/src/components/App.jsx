/* 
function based component
*/

/* 
/* 

/* 
// class based component  
import { Component } from "react"
import Hero from "./heroes"
class App extends Component {
  state = {
    firstlist : {
      title : "Avengers",
      list : ["Ironman","Thor","Hulk","Captain Amercia","Black Widow"]
    },
    secondlist : {
      title : "Justice League",
      list : ["Batman","Superman","Flash","Wonder Women","Aquaman"]
    },
    thirdlist : {
      title : "Indic Heroes",
      list : ["Shaktiman","Krissh","Chota Bheem"]
    }
  }
  render(){
    return <div>
    <h1>Welcome to your life</h1>
    <hr />
    <Hero title={this.state.firstlist.title} list={this.state.firstlist.list} />
    <Hero title={this.state.secondlist.title} list={this.state.secondlist.list} />
    <Hero title={this.state.thirdlist.title} list={this.state.thirdlist.list} />
    </div>
  }
}

export default App 
*/
   
   
   
/*    
*/
import { useState } from "react";
import Hero from "./heroes";

function App() {
  let [state] = useState({
    firstlist : {
      title : "Avengers",
      list : ["Ironman","Thor","Hulk","Captain Amercia","Black Widow"]
    },
    secondlist : {
      title : "Justice League",
      list : ["Batman","Superman","Flash","Wonder Women","Aquaman"]
    },
    thirdlist : {
      title : "Indic Heroes",
      list : ["Shaktiman","Krissh","Chota Bheem"]
    }
  })
  return <div>
            <h1>Welcome to your life</h1>
            <hr/>
            <Hero title={state.firstlist.title} list={state.firstlist.list} />
            <Hero title={state.secondlist.title} list={state.secondlist.list} />
            <Hero title={state.thirdlist.title} list={state.thirdlist.list} />
        </div>
}
export default App 