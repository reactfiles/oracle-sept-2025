let mystyle = { 
    backgroundColor : "crimson", 
    color : "papayawhip", 
    padding : "10px", 
    fontFamily : "sans-serif" 
}

export default mystyle;