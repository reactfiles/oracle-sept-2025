import mystyle from "./assets/mystyle";
import "./assets/appstyle.css";
import oracle from "./assets/oracle.module.css";

let App = () => {
  // here 
  return   <div>
              <h1>Styles in React </h1>
              <article style={ { backgroundColor : "crimson", color : "papayawhip", padding : "10px", fontFamily : "sans-serif" } }>
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Inventore quam ducimus eveniet nulla impedit. Hic non nesciunt doloribus tempore deleniti sit aperiam animi debitis asperiores, reiciendis quam alias sed, sunt tempora perferendis nulla temporibus dolorum eum. Repudiandae perspiciatis facere exercitationem ad reiciendis, necessitatibus vitae suscipit earum nulla provident excepturi fugiat unde, consequuntur ex ratione praesentium. Repudiandae numquam consequatur officia. Voluptate ipsa asperiores quo vel repellat illum magnam assumenda consequatur optio nesciunt. Harum distinctio facilis tempora sequi, molestias iure odio obcaecati voluptates facere unde, minima dolor illo saepe hic error, corrupti dignissimos eveniet fuga. Qui unde maxime voluptatum vero voluptas possimus.
              </article>
              <hr />
              <article style={ {...mystyle, backgroundColor : "rgba(33, 82, 81, 1)" } }>
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Inventore quam ducimus eveniet nulla impedit. Hic non nesciunt doloribus tempore deleniti sit aperiam animi debitis asperiores, reiciendis quam alias sed, sunt tempora perferendis nulla temporibus dolorum eum. Repudiandae perspiciatis facere exercitationem ad reiciendis, necessitatibus vitae suscipit earum nulla provident excepturi fugiat unde, consequuntur ex ratione praesentium. Repudiandae numquam consequatur officia. Voluptate ipsa asperiores quo vel repellat illum magnam assumenda consequatur optio nesciunt. Harum distinctio facilis tempora sequi, molestias iure odio obcaecati voluptates facere unde, minima dolor illo saepe hic error, corrupti dignissimos eveniet fuga. Qui unde maxime voluptatum vero voluptas possimus.
              </article>
              <hr />
              <article className="box">
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Inventore quam ducimus eveniet nulla impedit. Hic non nesciunt doloribus tempore deleniti sit aperiam animi debitis asperiores, reiciendis quam alias sed, sunt tempora perferendis nulla temporibus dolorum eum. Repudiandae perspiciatis facere exercitationem ad reiciendis, necessitatibus vitae suscipit earum nulla provident excepturi fugiat unde, consequuntur ex ratione praesentium. Repudiandae numquam consequatur officia. Voluptate ipsa asperiores quo vel repellat illum magnam assumenda consequatur optio nesciunt. Harum distinctio facilis tempora sequi, molestias iure odio obcaecati voluptates facere unde, minima dolor illo saepe hic error, corrupti dignissimos eveniet fuga. Qui unde maxime voluptatum vero voluptas possimus.
              </article>
              <hr />
              <article className={oracle.player}>
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Inventore quam ducimus eveniet nulla impedit. Hic non nesciunt doloribus tempore deleniti sit aperiam animi debitis asperiores, reiciendis quam alias sed, sunt tempora perferendis nulla temporibus dolorum eum. Repudiandae perspiciatis facere exercitationem ad reiciendis, necessitatibus vitae suscipit earum nulla provident excepturi fugiat unde, consequuntur ex ratione praesentium. Repudiandae numquam consequatur officia. Voluptate ipsa asperiores quo vel repellat illum magnam assumenda consequatur optio nesciunt. Harum distinctio facilis tempora sequi, molestias iure odio obcaecati voluptates facere unde, minima dolor illo saepe hic error, corrupti dignissimos eveniet fuga. Qui unde maxime voluptatum vero voluptas possimus.
              </article>
            </div>
}

export default App