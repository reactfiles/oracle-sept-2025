import React, { Component } from "react"

class App extends Component{
  state = {
    power : 0,
    tempPower : 0
  }
  powerRef = React.createRef();
  /* 
  constructor(){
    super();
    this.increasePower = this.increasePower.bind(this);
  } 
  */
  render(){
    return <div className="container">
            <h1>Events in React</h1>
            <h2>Power is { this.state.power }</h2>
            {/* 
            increase power
            decreate power
            set power

            button
            input type number
            input type range
            input type text
            input + button

            inline function 
            extenal function
            */}
            {/* <button onClick={this.increasePower.bind(this)} className="btn btn-primary ">Increase Power</button> */}
            <button onClick={this.increasePower} className="btn btn-primary ">Increase Power</button>
            &nbsp;
            <button onClick={this.decreasePower} className="btn btn-danger ">Decrease Power</button>
            &nbsp;
            <button onClick={this.setPower} className="btn btn-warning ">Set Power to 10</button>
            <hr />
            <input type="number" onInput={this.inputSetPower} />
            <hr />
            <input type="range" onInput={this.inputSetPower} />
            <hr />
            <input onInput={this.inputSetPower} />
            <hr/>
            <input onChange={this.setTempPower} value={this.state.tempPower} type="number"  />
            &nbsp;
            <button onClick={this.setPowerFromTemp} className="btn btn-secondary">Set Power</button>
            &nbsp;
            { this.state.tempPower }
          </div>
  }
  increasePower = () => {
    this.setState({power : this.state.power+1})
  }
  decreasePower = () => {
    this.setState({power : this.state.power-1})
  }
  setPower = () => {
    this.setState({power : 10})
  }
  inputSetPower = (evt) => {
    this.setState({power : Number(evt.target.value)})
  }
  setTempPower = (evt) => {
    this.setState({tempPower : Number(evt.target.value)})
  }
  setPowerFromTemp = () => {
    this.setState({power : this.state.tempPower})
  }
}

export default App
