import { useState } from "react"

function App() {
  let [power, setPower] = useState(0);
  let [agree, setAgree] = useState(true);

  return <div className="container">
            <h1>Welcome to your life</h1>
            <h2>Power { power }</h2>
            <input onInput={(evt)=> setPower(Number(evt.target.value))} type="range" step={5} />
            <hr />
            <input type="checkbox" value={agree} checked={agree} onChange={(evt) => setAgree(evt.target.value=="TRUE" ? true : false)} />{ agree ? "TRUE" : "FALSE" }
          </div>
}

export default App
