import { useState, createRef } from "react";
import Hero from "./components/heroes"

let HookApp  = () => {
    let [state, setState] = useState({
        title : "Default Title", 
        list : []
    });
    let ipref1 = createRef();
    let ipref2 = createRef();
    let clickHandler = () => {
        if(ipref2.current.value !== ""){
            setState({...state, list : [...state.list, ipref2.current.value]});
            ipref2.current.value = "";
            ipref2.current.focus();
        }else{
            alert("input can not be blank")
        }
    }
    return <div className="container">
            <h1 className="display-2">Welcome to your life</h1>
            <div className="mb-3">
              <label htmlFor="herotitle" className="form-label">Title</label>
              <input ref={ipref1} className="form-control" id="herotitle"/>
            </div>
            <button onClick={()=> setState({...state, title : ipref1.current.value}) } type="button" className="btn btn-primary">Change Title</button>
            <hr />
            <div className="mb-3">
              <label htmlFor="heroes" className="form-label">Add Hero</label>
              <input ref={ipref2} className="form-control" id="heroes"/>
            </div>
            <button onClick={clickHandler} type="button" className="btn btn-primary">Add Hero</button>
            <hr />
            <Hero title={state.title} list={state.list}/>
          </div>
}


export default HookApp
