import { createRoot } from 'react-dom/client'
// import App from './App.jsx'
import HookApp from './HookApp.jsx'

createRoot(document.getElementById('root')).render( <HookApp /> )
