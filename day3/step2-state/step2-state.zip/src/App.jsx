import { Component, createRef } from "react"
import Hero from "./components/heroes"

class App extends Component {
  state = {
     title : "Default Title", 
      list : []
  }
  ipref1 = createRef();
  ipref2 = createRef();
  render(){
    return <div className="container">
            <h1 className="display-2">Welcome to your life</h1>
            <div className="mb-3">
              <label htmlFor="herotitle" className="form-label">Title</label>
              {/* <input onBlur={(evt)=> this.setState({title : evt.target.value, list : [...this.state.list] }) } className="form-control" id="herotitle"/> */}
              <input ref={this.ipref1} className="form-control" id="herotitle"/>
            </div>
            <button onClick={()=> this.setState({...this.state, title : this.ipref1.current.value}) } type="button" className="btn btn-primary">Change Title</button>
            <hr />
            <div className="mb-3">
              <label htmlFor="heroes" className="form-label">Add Hero</label>
              {/* <input onBlur={(evt)=> this.setState({title : evt.target.value, list : [...this.state.list] }) } className="form-control" id="herotitle"/> */}
              <input ref={this.ipref2} className="form-control" id="heroes"/>
            </div>
            <button onClick={()=> {
              if(this.ipref2.current.value !== ""){
                this.setState({...this.state, list : [...this.state.list, this.ipref2.current.value]});
                this.ipref2.current.value = "";
                this.ipref2.current.focus();
              }else{
                alert("input can not be blank")
              }
            } } type="button" className="btn btn-primary">Add Hero</button>
            <hr />
            <Hero title={this.state.title} list={this.state.list}/>
          </div>
  }
}

export default App
