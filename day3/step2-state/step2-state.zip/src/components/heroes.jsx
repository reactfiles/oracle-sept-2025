let Hero = (props) => {
    return <div>
                <h2>{ props.title }</h2>
                <ol>
                    {props.list.map((val, idx) => <li key={idx}>{ val }</li>)}
                </ol>
            </div>
}

export default Hero;